﻿using Nancy;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace SchedulerMonitor
{
    public class SchedulerModule : NancyModule
    {
        public SchedulerModule()
        {
            Get["/SchedulersState/{TaskName}"]  = (p) =>
            {
                string result = string.Empty;

                var taskName = p.TaskName.Value;

                List< TaskModel> tasks = TaskSchedulerHelper.getTasks(taskName);

                result = JsonConvert.SerializeObject(tasks);

                return result;
            };

            Get["SchedulersState"] = Post["TaskName"] = (p) =>
            {
                string result = string.Empty;

                var taskName = p.TaskName.Value;

                List<TaskModel> tasks = TaskSchedulerHelper.getTasks(taskName);

                result = JsonConvert.SerializeObject(tasks);

                return result;
            };
        }


    }
}
